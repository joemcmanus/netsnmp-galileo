/*
 * module to include the modules
 */

config_require(tcp-mib/data_access/tcpConn)
config_require(tcp-mib/tcpConnectionTable/tcpConnectionTable)
