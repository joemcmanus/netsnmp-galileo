/*
 * module to include the modules
 */

config_require(tcp-mib/data_access/tcpConn)
config_require(tcp-mib/tcpConnTable/tcpConnTable)
config_require(tcp-mib/tcpConnTable/tcpConnTable_interface)
config_require(tcp-mib/tcpConnTable/tcpConnTable_data_access)
