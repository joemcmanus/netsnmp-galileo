config_require(mibII/updates)
config_exclude(mibII/snmp_mib)

void            init_snmp_mib_5_5(void);
