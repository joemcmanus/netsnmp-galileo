/*
 *  memory quantity mib groups
 *
 */
#ifndef _MIBGROUP_MEMORY_FREEBSD2_H
#define _MIBGROUP_MEMORY_FREEBSD2_H

#include "mibdefs.h"

extern void     init_memory_freebsd2(void);

#endif                          /* _MIBGROUP_MEMORY_FREEBSD2_H */
