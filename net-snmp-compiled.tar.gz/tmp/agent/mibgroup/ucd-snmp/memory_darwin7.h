/*
 *  memory quantity mib groups
 *
 */
#ifndef _MIBGROUP_MEMORY_DARWIN7_H
#define _MIBGROUP_MEMORY_DARWIN7_H

config_require(util_funcs/header_generic)

#include "mibdefs.h"

extern void     init_memory_darwin7(void);

#endif                          /* _MIBGROUP_MEMORY_DARWIN7_H */
