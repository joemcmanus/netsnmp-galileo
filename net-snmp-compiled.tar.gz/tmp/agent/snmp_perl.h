#ifndef SNMP_PERL_H
#define SNMP_PERL_H

#ifdef __cplusplus
extern "C" {
#endif

void init_perl(void);
void shutdown_perl(void);

#ifdef __cplusplus
}
#endif

#endif /* SNMP_PERL_H */
